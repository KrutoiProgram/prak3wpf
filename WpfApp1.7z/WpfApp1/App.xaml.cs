﻿using Firebase.Auth;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MVVMEssentials.Services;
using MVVMEssentials.Stores;
using MVVMEssentials.ViewModels;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;
using WpfApp1.ViewModels;
using WpfApp1.Views;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App :Application
    {
        private readonly IHost _host;

        public App()    
        {
            
            
                _host = Host.CreateDefaultBuilder()
                .ConfigureServices((context, service) =>
                {
                    string firebaseApiKey = context.Configuration.GetValue<string>("FIREBASE_API_KAY");

                    service.AddSingleton(new FirebaseAuthProvider(new FirebaseConfig(firebaseApiKey)));
                    service.AddSingleton<NavigationStore>();
                    service.AddSingleton<ModalNavigationStore>();
                    service.AddSingleton<NavigationService>();
                    service.AddSingleton(
                            services => new NavigationService<TaskManagerViewModel>(
                            services.GetRequiredService<NavigationStore>(),
                            () =>
                                new TaskManagerViewModel()));
                    service.AddSingleton(
                           services => new NavigationService<EditTaskViewModel>(
                           services.GetRequiredService<NavigationStore>(),
                           () =>
                               new EditTaskViewModel()));
                    service.AddSingleton(
                           services => new NavigationService<AddTaskViewModel>(
                           services.GetRequiredService<NavigationStore>(),
                           () =>
                               new AddTaskViewModel()));

                    service.AddSingleton(
                        services => new NavigationService<LoginViewModel>(
                            services.GetRequiredService<NavigationStore>(),
                            () => 
                                new LoginViewModel(services.GetRequiredService<FirebaseAuthProvider>(), 
                                    services.GetRequiredService<NavigationService<TaskManagerViewModel>>())));

                    //service.AddSingleton(
                    //    services => new NavigationService<LoginViewModel>(
                    //        services.GetRequiredService<NavigationStore>(),
                    //        () =>
                    //            new LoginViewModel(services.GetRequiredService<FirebaseAuthProvider>(),
                    //                services.GetRequiredService<NavigationService<EditTaskViewModel>>())));

                    //service.AddSingleton(
                    //    services => new NavigationService<LoginViewModel>(
                    //        services.GetRequiredService<NavigationStore>(),
                    //        () =>
                    //            new LoginViewModel(services.GetRequiredService<FirebaseAuthProvider>(),
                    //                services.GetRequiredService<NavigationService<AddTaskViewModel>>())));




                    service.AddSingleton<MainViewModel>();
                    service.AddSingleton<MainWindow>((services) => new MainWindow()
                    {
                        DataContext = services.GetRequiredService<MainViewModel>()
                    });
                    
                    
                })
                .Build();
            
        }
        protected override void OnStartup (StartupEventArgs e)
        {
            INavigationService navigationService = _host.Services.GetRequiredService<NavigationService<LoginViewModel>>();
            navigationService.Navigate();
            
            MainWindow = _host.Services.GetRequiredService<MainWindow>();

            
            
            MainWindow.Show();
            base.OnStartup(e);  
        }
    }
}
