﻿using Firebase.Auth;
using Firebase.Database;
using Firebase.Database.Query;
using MVVMEssentials.Services;
using MVVMEssentials.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Data;
using System.Windows.Threading;
using WpfApp1.Commands;
using WpfApp1.Models;

namespace WpfApp1.ViewModels
{
    public class TaskManagerViewModel : ViewModelBase
    {
        public static FirebaseClient firebase = new FirebaseClient("https://user-tasks-b8522-default-rtdb.firebaseio.com/");

        public ObservableCollection<Models.Task> tasks { get; set; }

        public string _selectedWorker { get; set; }

        public string _selectedDateSort { get; set; }

        public bool IsComplete { get; set; }

        public Dispatcher _dispatcher = Dispatcher.CurrentDispatcher;

        public List<string> _workers { get; set; } = new List<string>();

        public List<string> _dateSort { get; set;} = new List<string>() {"Сбросить","По возрастанию","По убыванию"};
            
      

        public TaskManagerViewModel()
        {

            _workers.Add("Сбросить");
            tasks = new ObservableCollection<Models.Task>();

            var users = firebase.Child("users").AsObservable<Models.User>().Subscribe(data =>
            {
                
                 
                
                _dispatcher.Invoke(new Action(() =>
                {
                    foreach (var item in data.Object.tasks.Values)
                    {
                        if (!string.IsNullOrWhiteSpace(item.title) && !string.IsNullOrWhiteSpace(item.DateOfCompletion) && !string.IsNullOrWhiteSpace(item.status)&&!tasks.Contains(item))
                        {
                            
                            tasks.Add(item);
                     
                            if (!_workers.Contains(item.FullName))
                            {
                               
                                _workers.Add(item.FullName);

                            }
                        }
                    }

                }));

                
            });

            FilterByFullName = new TaskManagerCommand(obj =>

            {
                if(_selectedWorker!="Сбросить")
                {
                    ApplyFilters();
                }
                
            });
            IsCompleteFilter = new TaskManagerCommand(obj =>
            {

                ApplyFilters();
            });
            SortByDate = new TaskManagerCommand(obj =>

            {
                if (_selectedDateSort != "Сбросить")
                {
                    ApplyFilters();
                }


            });
        }

        public TaskManagerCommand FilterByFullName { get; set; }

        public TaskManagerCommand SortByDate { get; set; }

        public TaskManagerCommand IsCompleteFilter { get; set; }

        public void ApplyFilters()
        {

            tasks.Clear();
            
            
            var users = firebase.Child("users").AsObservable<Models.User>().Subscribe(data =>
            {



                _dispatcher.Invoke(new Action(() =>
                {
                        foreach (var item in data.Object.tasks.Values)
                        {
                            if (!string.IsNullOrWhiteSpace(item.title) && !string.IsNullOrWhiteSpace(item.DateOfCompletion) && !string.IsNullOrWhiteSpace(item.status) && !tasks.Contains(item))
                            {
                                if(item.FullName==_selectedWorker)
                                {
                                    tasks.Add(item);
                                }
                               
                            }
                        }

                }));


            });
        }
       
    }
}
