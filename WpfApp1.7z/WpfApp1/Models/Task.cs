﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    public class Task
    {
        public string DateOfCompletion { get; set; }

        public string description { get; set; }

        public string status { get; set; }

        public string title { get; set; }

        public string FullName { get; set; }
    }
}
